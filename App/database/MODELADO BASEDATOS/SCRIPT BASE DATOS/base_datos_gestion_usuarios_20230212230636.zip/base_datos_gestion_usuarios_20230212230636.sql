-- MySQL dump 10.13  Distrib 8.0.30, for Win64 (x86_64)
--
-- Host: localhost    Database: app_permisos
-- ------------------------------------------------------
-- Server version	8.0.30

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `modulo`
--

DROP TABLE IF EXISTS `modulo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `modulo` (
  `id_modulo` int NOT NULL AUTO_INCREMENT,
  `name_modulo` varchar(80) NOT NULL,
  `key_modulo` varchar(50) NOT NULL,
  PRIMARY KEY (`id_modulo`)
) ENGINE=InnoDB AUTO_INCREMENT=297 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `modulo`
--

LOCK TABLES `modulo` WRITE;
/*!40000 ALTER TABLE `modulo` DISABLE KEYS */;
INSERT INTO `modulo` VALUES (288,'Dashboard','dashboard'),(289,'Usuarios','usuarios'),(290,'Roles','roles'),(291,'Permisos','permisos'),(292,'Módulo','modulo'),(293,'Ventas',''),(294,'Productos',''),(295,'Compras',''),(296,'Configuracion','configuracion');
/*!40000 ALTER TABLE `modulo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permission`
--

DROP TABLE IF EXISTS `permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `permission` (
  `id_permiso` int NOT NULL AUTO_INCREMENT,
  `name_permiso` varchar(70) NOT NULL,
  `descripcion` varchar(80) NOT NULL,
  `id_modulo` int NOT NULL,
  PRIMARY KEY (`id_permiso`),
  KEY `fk_PERMISSION_MODULO_idx` (`id_modulo`),
  CONSTRAINT `fk_PERMISSION_MODULO` FOREIGN KEY (`id_modulo`) REFERENCES `modulo` (`id_modulo`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permission`
--

LOCK TABLES `permission` WRITE;
/*!40000 ALTER TABLE `permission` DISABLE KEYS */;
INSERT INTO `permission` VALUES (16,'Usuario.create','crear usuarios',289),(17,'Usuario.editar','editar usuarios',289),(18,'Usuario.delete','eliminar usuarios',289),(19,'Usuario.index','ver usuarios',289),(20,'Rol.create','crear roles',290),(21,'Rol.editar','editar roles',290),(22,'Rol.delete','eliminar roles',290),(23,'Rol.index','ver roles',290),(25,'Modulo.create','craer modulos',292),(26,'Modulo.editar','editar modulos',292),(27,'Modulo.delete','eliminar modulos',292),(28,'Modulo.index','ver modulos',292),(29,'Permiso.create','crear permisos',291),(30,'Permiso.editar','editar permisos',291),(31,'Permiso.delete','eliminar permisos',291),(32,'Permiso.index','ver permisos',291),(33,'Dashboard.index','ver página principal',288),(34,'Config.respaldo','crear copia seguridad',296),(35,'Config.restaurar','restaurar BD',296);
/*!40000 ALTER TABLE `permission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rol`
--

DROP TABLE IF EXISTS `rol`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `rol` (
  `id_role` int NOT NULL AUTO_INCREMENT,
  `name_rol` varchar(60) NOT NULL,
  PRIMARY KEY (`id_role`)
) ENGINE=InnoDB AUTO_INCREMENT=58 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rol`
--

LOCK TABLES `rol` WRITE;
/*!40000 ALTER TABLE `rol` DISABLE KEYS */;
INSERT INTO `rol` VALUES (9,'Administrador'),(54,'Ing.Sistemas'),(55,'Contador');
/*!40000 ALTER TABLE `rol` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rol_has_permission`
--

DROP TABLE IF EXISTS `rol_has_permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `rol_has_permission` (
  `id_permiso` int NOT NULL,
  `id_role` int NOT NULL,
  PRIMARY KEY (`id_permiso`,`id_role`),
  KEY `fk_PERMISSION_has_ROL_ROL1_idx` (`id_role`),
  KEY `fk_PERMISSION_has_ROL_PERMISSION1_idx` (`id_permiso`),
  CONSTRAINT `fk_PERMISSION_has_ROL_PERMISSION1` FOREIGN KEY (`id_permiso`) REFERENCES `permission` (`id_permiso`),
  CONSTRAINT `fk_PERMISSION_has_ROL_ROL1` FOREIGN KEY (`id_role`) REFERENCES `rol` (`id_role`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rol_has_permission`
--

LOCK TABLES `rol_has_permission` WRITE;
/*!40000 ALTER TABLE `rol_has_permission` DISABLE KEYS */;
INSERT INTO `rol_has_permission` VALUES (16,9),(18,9),(19,9),(20,9),(21,9),(22,9),(23,9),(33,9),(34,9),(35,9),(25,54),(28,54),(29,54);
/*!40000 ALTER TABLE `rol_has_permission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuario`
--

DROP TABLE IF EXISTS `usuario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usuario` (
  `id_usuario` int NOT NULL AUTO_INCREMENT,
  `username` varchar(70) NOT NULL,
  `email` varchar(95) NOT NULL,
  `pasword` varchar(60) NOT NULL,
  `foto` varchar(300) DEFAULT NULL,
  PRIMARY KEY (`id_usuario`)
) ENGINE=InnoDB AUTO_INCREMENT=55 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuario`
--

LOCK TABLES `usuario` WRITE;
/*!40000 ALTER TABLE `usuario` DISABLE KEYS */;
INSERT INTO `usuario` VALUES (48,'Abelardo Adrian','adriaaanroosales@gmail.com','25f9e794323b453885f5181f1b624d0b','20230123_045644151316399.jpg'),(53,'danilogustavorc','danilogustavorc@gmail.com','903809e873994154b85b0d4adc45f43f','20230206_0046101458037897.jpg'),(54,'Irma3400','Irma@hotmail.com','dbc63656741bb61d86093fbf3fe8309c',NULL);
/*!40000 ALTER TABLE `usuario` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuario_has_role`
--

DROP TABLE IF EXISTS `usuario_has_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usuario_has_role` (
  `id_usuario` int NOT NULL,
  `id_role` int NOT NULL,
  `estado` enum('1','0') CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `session` enum('0','1') NOT NULL,
  PRIMARY KEY (`id_usuario`,`id_role`),
  KEY `fk_USUARIO_has_ROL_ROL1_idx` (`id_role`),
  KEY `fk_USUARIO_has_ROL_USUARIO1_idx` (`id_usuario`),
  CONSTRAINT `fk_USUARIO_has_ROL_ROL1` FOREIGN KEY (`id_role`) REFERENCES `rol` (`id_role`),
  CONSTRAINT `fk_USUARIO_has_ROL_USUARIO1` FOREIGN KEY (`id_usuario`) REFERENCES `usuario` (`id_usuario`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuario_has_role`
--

LOCK TABLES `usuario_has_role` WRITE;
/*!40000 ALTER TABLE `usuario_has_role` DISABLE KEYS */;
INSERT INTO `usuario_has_role` VALUES (48,9,'1','0'),(53,54,'1','0'),(54,54,'1','0');
/*!40000 ALTER TABLE `usuario_has_role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'app_permisos'
--
/*!50003 DROP PROCEDURE IF EXISTS `proc_autorize` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_autorize`(idrol int,permiso_ varchar(70))
begin
select *from rol_has_permission rp 
inner join permission p on 
rp.id_permiso=p.id_permiso
where rp.id_role=idrol and p.name_permiso=permiso_;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_profile` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_profile`(email_ varchar(90), idrol int)
begin
 SELECT u.id_usuario,u.email,u.username,r.name_rol,u.foto,r.id_role
from usuario_has_role ur inner join usuario u 
on ur.id_usuario = u.id_usuario inner join rol r
on ur.id_role = r.id_role where 
u.email=email_ and r.id_role=idrol;
 end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_roles_asignados` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_roles_asignados`(id integer)
begin
  select r.name_rol from 
 rol r where r.id_role in(select ur.id_role from 
 usuario_has_role ur where ur.id_usuario=id);
 end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_roles_del_usuario` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_roles_del_usuario`(id int)
begin
select r.name_rol from 
usuario_has_role ur inner join usuario u on ur.id_usuario=u.id_usuario
inner join rol r on ur.id_role=r.id_role
where u.id_usuario=id;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `proc_roles_no_asignados` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_roles_no_asignados`(id integer)
begin
 select r.name_rol from 
 rol r where r.id_role not in(select ur.id_role from 
 usuario_has_role ur where ur.id_usuario=id);
 end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-02-12 18:06:37
